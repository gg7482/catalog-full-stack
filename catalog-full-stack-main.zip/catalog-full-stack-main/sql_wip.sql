-- SQLite
delete from category;
delete from item;
delete from user;
-- update item set user_id = 2 where id < 7;
--  insert into item values ('Bat',12,'Hockey Bat',datetime(CURRENT_TIMESTAMP,'localtime'),2,1);
-- select datetime(CURRENT_TIMESTAMP,'localtime');
select * from category;
select * from item ;
select * from user;
